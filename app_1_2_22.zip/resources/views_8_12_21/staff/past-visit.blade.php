

@extends('layouts.staff')

@section('content')


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Past Visits</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item"><a href="#">Staff</a>
					</li>
					<li class="breadcrumb-item active">Past Visits
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					<!--<div class="col-12 text-right mb-2"><a href="add-staff.html" class="btn btn-danger rounded-0">Add New</a></div>-->
						<div class="col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
										<table class="table table-striped table-bordered dom-jQuery-events">
											<thead>
											   <tr>
												<th>Date</th>
												<th>Time</th>
												<th>Client Name</th>
												<th>Address</th>
												<th>Status</th>
												<th>Actions</th>   
											   </tr>
											</thead>
											<tbody>
												@if(count($record) > 0)
													@foreach($record as $each)
														<tr>
															<td>{{$each->date_in}} </td>
															
															<td>{{$each->time_in}}</td>
															<?php
																
																$clientDetail = App\Helpers\CommonHelper::getClientDetails($each->client_id);
															?>
															<td>{{$clientDetail['name']}} </td>
															<td>{{$clientDetail['address']}} </td>
															<td>Completed</td>
															<td><a href="#">View Detail</a> </td>
															
														</tr>
													@endforeach
												@endif
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
										
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   

@endsection