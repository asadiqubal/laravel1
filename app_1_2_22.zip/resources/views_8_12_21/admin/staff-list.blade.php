@extends('layouts.app')


@section('content')


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Staff List</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Staff List
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					<div class="col-12 text-right mb-2"><a href="{{url('admin/add-staff')}}" class="btn btn-danger rounded-0">Add New</a></div>
						<div class="col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
									{{-- error --}}
										 @if(session('success'))
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												{{ session('success') }}
											</div>
											@endif
											@if(session('error'))
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												{{ session('error') }}
											</div>
											@endif
										<table class="table table-striped table-bordered dom-jQuery-events">
											<thead>
											   <tr>
												<th>Name</th>
												<th>Date</th>
												<th>Joining Date</th>
												<th>Registery No.</th>
												<th>Licence No.</th>
												<th>Expiry Date</th>
												<th>Actions</th>   
											   </tr>
											</thead>
											<tbody>
												@if(count($staff_list) > 0)
													@foreach($staff_list as $eachitem)
													<tr>
													   
														<td><img width="40" height="40" src="{{asset('staff')}}/{{$eachitem['photo']}}" class="rounded-circle mr-1" alt=""> {{$eachitem['name']}} @if($eachitem['employee_code']) - {{$eachitem['employee_code']}} @endif </td>
														 <td>10 Oct 2021</td>
														 <td>{{$eachitem['joining_date']}}</td>
														  <td>{{$eachitem['registery_no']}}</td>
														  <td>{{$eachitem['licence_no']}}</td>
														
															<td>{{$eachitem['expiry_date']}}</td>
														<td><a href="{{url('admin/edit-staff')}}/{{$eachitem['id']}}">Edit</a> | <a onclick="deleteFunc('Staff',{{$eachitem['id']}})" href="#">Delete</a></td>
													</tr>
													@endforeach
												@endif
												
											</tfoot>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

 @endsection