@extends('layouts.app')


@section('content')
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Schedule</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a></li>
					<li class="breadcrumb-item active">Schedule</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="advance-examples">
				    <div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-content collapse show">
									<div class="card-body">
										<div id='fc-selectable1'></div>
									</div>
								</div>
								
								
							</div>
						</div>
					</div>
				
											
				</section>	
	
        </div>
      </div>
    </div>
	
@endsection
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   
@section('footer-js')
	<script>
		        $("#fc-selectable1").fullCalendar({

            header: { left: "prev,next today", center: "title", right: "month,agendaWeek,agendaDay" },

            //defaultDate: "2016-06-12",

            selectable: !0,

            selectHelper: !0,

            select: function (t, e) {

                var a,

                    n = prompt("Event Title:");

                n && ((a = { title: n, start: t, end: e }), $("#fc-selectable").fullCalendar("renderEvent", a, !0)), $("#fc-selectable").fullCalendar("unselect");

            },

            editable: !0,

            eventLimit: !0,

            events: [
				<?php
					if(count($schedule_list) > 0){
						foreach($schedule_list as $each){
							$staffDetail = App\Helpers\CommonHelper::getStaffDetails($each->staff_id);
							
							$clientDetail = App\Helpers\CommonHelper::getClientDetails($each->client_id);
				?>
					{ title: "<?php echo $staffDetail['name']; ?> - <?php echo $clientDetail['name']; ?>", start: "<?php echo $each['date_in']; ?>T<?php echo $each['time_in']; ?>", end: "<?php echo $each['date_in']; ?>T<?php echo $each['time_out']; ?>" },
				<?php
						}
					}
				?>
                /* { title: "All Day Event", start: "2021-10-01" },

                { title: "Long Event", start: "2021-12-03", end: "2021-12-04" },

                { id: 999, title: "Repeating Event", start: "2021-10-09T16:00:00" },

                { id: 999, title: "Repeating Event", start: "2021-10-16T16:00:00" },

                { title: "Conference", start: "2021-10-11", end: "2021-10-13" },

                { title: "Meeting", start: "2021-10-12T10:30:00", end: "2021-10-12T12:30:00" },

                { title: "Lunch", start: "2021-10-12T12:00:00" },

                { title: "Meeting", start: "2021-10-12T14:30:00" },

                { title: "Happy Hour", start: "2021-10-12T17:30:00" },

                { title: "Dinner", start: "2021-10-12T20:00:00" },

                { title: "Birthday Party", start: "2021-10-13T07:00:00" },

                { title: "Click for Google", url: "http://google.com/", start: "2021-10-28" }, */

            ],

        });

	</script>
@endsection

 
