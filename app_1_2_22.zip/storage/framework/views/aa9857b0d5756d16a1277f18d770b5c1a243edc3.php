<p><?php echo $message2; ?>.</p>
<?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/email/new-user-create.blade.php ENDPATH**/ ?>