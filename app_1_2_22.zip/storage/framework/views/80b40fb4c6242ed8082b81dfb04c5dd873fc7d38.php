


<?php $__env->startSection('content'); ?>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Schedule</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a></li>
					<li class="breadcrumb-item active">Schedule</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="advance-examples">
				    <div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-content collapse show">
									<div class="card-body">
										<div id='fc-selectable'></div>
									</div>
								</div>
								
								
							</div>
						</div>
					</div>
				
											
				</section>	
	
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   
   

 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/admin/schedule.blade.php ENDPATH**/ ?>