


<?php $__env->startSection('content'); ?>


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Staff List</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Staff List
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					<div class="col-12 text-right mb-2"><a href="<?php echo e(url('add-staff')); ?>" class="btn btn-danger rounded-0">Add New</a></div>
						<div class="col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
										<table class="table table-striped table-bordered dom-jQuery-events">
											<thead>
											   <tr>
												<th>Name</th>
												<th>Date</th>
												<th>Joining Date</th>
												<th>Registery No.</th>
												<th>Licence No.</th>
												<th>Expiry Date</th>
												<th>Actions</th>   
											   </tr>
											</thead>
											<tbody>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt=""> John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt="">John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt="">John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt="">John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt="">John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
												<tr>
													<td><img width="40" height="40" src="app-assets/images/user.jpg" class="rounded-circle mr-1" alt="">John</td>
													<td>10 Oct 2021</td>
													<td>00002</td>
													<td>10 Oct 2021</td>
													<td>LC-00002</td>
													<td>10 Oct 2021</td>
													<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
												</tr>
											</tfoot>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/staff-list.blade.php ENDPATH**/ ?>