


<?php $__env->startSection('content'); ?>

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Timesheet</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Timesheet
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					
				<div class="row">
					<div class="col-12">
						<div class="card">
						   
							<div class="card-content collapse show">
								<div class="card-body card-dashboard">
								<div class="row justify-content-end">
									<div class="col-md-2 col-sm-12 col-12 pt-1 text-right"><b>Select Date</b></div>		
									<div class="col-md-3 col-sm-12 col-12 mb-2 text-right"><input type="date" class="form-control"></div>

								</div>
								
								
									<table class="table table-striped table-bordered dom-jQuery-events">
										<thead>
											<tr>
											   <th>Employee Name</th>
												<th>Time In</th>
												<th>Time Out</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
										   <tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											<tr>
												<td>John </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
											</tr>
											
										</tfoot>
									</table>
							   
										
										
										

							   </div>
							</div>
						</div>
					</div>
				</div>	
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/admin/timesheet.blade.php ENDPATH**/ ?>