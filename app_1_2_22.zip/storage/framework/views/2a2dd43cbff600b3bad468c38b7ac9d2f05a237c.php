<?php echo e($slot); ?>

<?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>