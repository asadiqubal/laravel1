<?php $__env->startSection('content'); ?>




    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Add Staff</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Add Staff
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					
						<div class="col-md-12 col-sm-12 col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
									
										 <?php if(session('success')): ?>
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												<?php echo e(session('success')); ?>

											</div>
											<?php endif; ?>
											<?php if(session('error')): ?>
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												<?php echo e(session('error')); ?>

											</div>
											<?php endif; ?>
											<form id="addStaffForm" class="form-horizontal form-simple" method="POST" action="<?php echo e(url('admin/submitaddStaff')); ?>" novalidate  enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
											<?php if(isset($id) && !empty($id)): ?>
												<input type="hidden" name="id" value="<?php echo e($id); ?>">
												<input type="hidden" name="user_id" value="<?php echo e($staffDetail->user_id); ?>">
											<?php endif; ?>
											<div class="form-body">
												<div class="row">
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput3">Employee Code</label>
															<input type="text" id="projectinput3" class="form-control" name="employee_code" value="<?php if(isset($staffDetail->employee_code) && !empty($staffDetail->employee_code)): ?> <?php echo e($staffDetail->employee_code); ?> <?php else: ?> <?php echo e(old('employee_code')); ?> <?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput3">Name</label>
															<input type="text" id="projectinput3" class="form-control" name="name" value="<?php if(isset($staffDetail->name) && !empty($staffDetail->name)): ?><?php echo e($staffDetail->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>">
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput5">Phone</label>
															<input type="text" id="projectinput5" class="form-control" name="phone" value="<?php if(isset($staffDetail->phone) && !empty($staffDetail->phone)): ?><?php echo e($staffDetail->phone); ?><?php else: ?><?php echo e(old('phone')); ?><?php endif; ?>">
														</div>
														
													</div>
													<div class="col-md-6 col-sm-12 col-12">
													
													
														<div class="form-group">
															<label for="email">Email</label>
															<input type="email" id="email" class="form-control" name="email" value="<?php if(isset($staffDetail->email) && !empty($staffDetail->email)): ?><?php echo e($staffDetail->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
													
													
														<div class="form-group">
															<label for="age">Age</label>
															<input type="text" id="age" class="form-control" name="age" value="<?php if(isset($staffDetail->age) && !empty($staffDetail->age)): ?><?php echo e($staffDetail->age); ?><?php else: ?><?php echo e(old('age')); ?><?php endif; ?>">
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
													
													
														<div class="form-group">
															<label for="hourly_rate">Hourly Rate($)</label>
															<input type="text" id="hourly_rate" class="form-control" name="hourly_rate" value="<?php if(isset($staffDetail->hourly_rate) && !empty($staffDetail->hourly_rate)): ?><?php echo e($staffDetail->hourly_rate); ?><?php else: ?><?php echo e(old('hourly_rate')); ?><?php endif; ?>">
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="joining_date">Joining Date</label>
															<input type="date" id="joining_date" class="form-control" name="joining_date" value="<?php if(isset($staffDetail->joining_date) && !empty($staffDetail->joining_date)): ?><?php echo e($staffDetail->joining_date); ?><?php else: ?><?php echo e(old('joining_date')); ?><?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="registery_no">Registery No</label>
															<input type="text" id="registery_no" class="form-control" name="registery_no" value="<?php if(isset($staffDetail->registery_no) && !empty($staffDetail->registery_no)): ?><?php echo e($staffDetail->registery_no); ?><?php else: ?><?php echo e(old('registery_no')); ?><?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="licence_no">Licence No</label>
															<input type="text" id="licence_no" class="form-control" name="licence_no" value="<?php if(isset($staffDetail->licence_no) && !empty($staffDetail->licence_no)): ?><?php echo e($staffDetail->licence_no); ?><?php else: ?> <?php echo e(old('licence_no')); ?><?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="expiry_date">Expiry Date</label>
															<input type="date" id="expiry_date" class="form-control" name="expiry_date" value="<?php if(isset($staffDetail->expiry_date) && !empty($staffDetail->expiry_date)): ?><?php echo e($staffDetail->expiry_date); ?><?php else: ?><?php echo e(old('expiry_date')); ?><?php endif; ?>">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput4">Address</label>
															<textarea id="projectinput4" name="address" class="form-control"> <?php if(isset($staffDetail->address) && !empty($staffDetail->address)): ?><?php echo e($staffDetail->address); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?></textarea>
															
														</div>
														
													</div>
												
												
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput4">Staff Photo</label>
															<input type="file" class="form-control" name="image">
															<?php if(isset($staffDetail->photo) && $staffDetail->photo): ?>
																<input type="hidden" value="<?php echo e($staffDetail->photo); ?>" name="old_image">
															<?php endif; ?>
														</div>
														
													</div>
													
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput4">Status</label>
															<select name="status" class="form-control status">
																<option <?php if(isset($staffDetail->status) && $staffDetail->status == "1"){ echo "selected"; }  ?> value="1">Active</option>
																<option <?php if(isset($staffDetail->status) && $staffDetail->status == "2"){ echo "selected"; }  ?> value="2">Past</option>
															
															</select>
														</div>
														
													</div>
													
													<div class="col-md-6 col-sm-12 col-12 leaving_date_div" <?php if(isset($staffDetail->status) && $staffDetail->status == "2"){ ?> style="display:block;" <?php }else{ ?> style="display:none;" <?php }  ?> >
														<div class="form-group">
															<label for="projectinput4">Leaving date</label>
															<input type="date" id="leaving_date" class="form-control" name="leaving_date" value="<?php if(isset($staffDetail->leaving_date) && !empty($staffDetail->leaving_date)): ?><?php echo e($staffDetail->leaving_date); ?><?php else: ?><?php echo e(old('leaving_date')); ?><?php endif; ?>">
														</div>
														
													</div>
													
													<div class="col-md-6 col-sm-12 col-12 leaving_reason_div" <?php if(isset($staffDetail->status) && $staffDetail->status == "1"){ ?> style="display:none;" <?php }else{ ?> style="display:block;" <?php }  ?>>
														<div class="form-group">
															<label for="projectinput4">Leaving reason</label>
															<select name="leaving_reason" class="form-control">
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Fired"){ echo "selected"; }  ?> value="Fired">Fired</option>
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Switched to another job"){ echo "selected"; }  ?> value="Switched to another job">Switched to another job</option>
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Health ground"){ echo "selected"; }  ?> value="Health ground">Health ground</option>
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Moved to another city"){ echo "selected"; }  ?> value="Moved to another city">Moved to another city</option>
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Retired"){ echo "selected"; }  ?> value="Retired">Retired</option>
																<option <?php if(isset($staffDetail->leaving_reason) && $staffDetail->leaving_reason == "Personal"){ echo "selected"; }  ?> value="Personal">Personal</option>
															
															</select>
														</div>
														
													</div>
													
												</div>
												
											   												
											</div>

											<div class="form-actions text-right">
												<button name="submit" type="submit" class="btn btn-info rounded-0">
													Submit
												</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   
<?php $__env->stopSection(); ?>


 
 <?php $__env->startSection('footer-js'); ?>
	<script>
		$(document).ready(function(){
			$('.status').on('change', function() {
				var selc =  $(this).find(":selected").val();
				
				if(selc == "1"){
					$('.leaving_date_div').hide();
					$('.leaving_reason_div').hide();
				}else{
					$('.leaving_date_div').show();
					$('.leaving_reason_div').show();
				}
			});

		});
	</script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/admin/add-staff.blade.php ENDPATH**/ ?>