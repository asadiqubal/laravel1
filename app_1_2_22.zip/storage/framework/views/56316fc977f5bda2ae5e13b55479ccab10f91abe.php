<?php $__env->startSection('content'); ?>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Schedule</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a></li>
					<li class="breadcrumb-item active">Schedule</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		 
										 <?php if(session('success')): ?>
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												<?php echo e(session('success')); ?>

											</div>
											<?php endif; ?>
											<?php if(session('error')): ?>
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												<?php echo e(session('error')); ?>

											</div>
											<?php endif; ?>
				<section id="advance-examples">
				    <div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-content collapse show">
									<div class="card-body">
										
										<div id='fc-selectable1'></div>
										
										<?php
										 $scheduleArray = array();
										?>
										<?php if(count($record)): ?>
											<?php
												$i=1;
												$j = 0;
												$scheduleArray = array();
											?>
											<?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php
													 $scheduleArray[$j]['id'] = $eachval['id'];
													$scheduleArray[$j]['date_in'] = $eachval['date_in'];
													$scheduleArray[$j]['time_in'] = $eachval['time_in'];
													$scheduleArray[$j]['time_out'] = $eachval['time_out'];

													
													$staffDetail = App\Helpers\CommonHelper::getStaffDetails($eachval->staff_id);
							
													$clientDetail = App\Helpers\CommonHelper::getClientDetails($eachval->client_id);
							
												?>
												<?php
												$i++;
												$j++;
											?>
											<div id="myModal_<?php echo $eachval['id']; ?>" class="modal fade" role="dialog">
											  <div class="modal-dialog">
											
											
												<div class="modal-content" style="top: 120px;">
														<div class="modal-header" style="float: right;display: block;">
											<button style="float: right;top: -3px;border: none;color: red;" type="button" class="close" data-dismiss="modal">&times;</button>      </div>

												  <div class="modal-body">
													<div class="text-right">
														<?php if($eachval['status'] == 0){ 
																$changeto = "1";
																?>
																<p><a href="<?php echo e(url('staff/change-status')); ?>/<?php echo e($eachval['id']); ?>/<?php echo e($changeto); ?>" onclick="return confirm('Are you sure?')" class="btn btn-info">Mark as Done</a></p>
																<?php }else{ 
																$changeto = "0";
																?>
																
																<p><a href="<?php echo e(url('staff/change-status')); ?>/<?php echo e($eachval['id']); ?>/<?php echo e($changeto); ?>" onclick="return confirm('Are you sure?')" class="btn btn-info">Mark as To Do</a></p>
																<?php
																}
																?>
													</div>
													<p><b><?php echo e(date('d M Y',strtotime($eachval['date_in']))); ?> (<?php echo e($eachval['time_in']); ?> - <?php echo e($eachval['time_out']); ?>)</b></p>
													<p><b> Client:</b>  <?php echo e($clientDetail['name']); ?></p>
													<p><b>Client Address:</b>  <?php echo e($clientDetail['address']); ?></p>
													<!--<p><b>Staff:</b>  <?php echo e($staffDetail['name']); ?> ( <?php echo e($staffDetail['employee_code']); ?> )</p>-->
													
													<p><b>Status:</b>  <?php if($eachval['status'] == 0){ ?>To Do <?php }else{ ?> Done <?php } ?></p>
													
													<p><b>Admin Notes:</b> <?php if($eachval['admin_notes']): ?><?php echo e($eachval['admin_notes']); ?> <?php else: ?> <?php echo e("NA"); ?> <?php endif; ?> </p>
													<p><b>Staff Notes:</b> <?php if($eachval['staff_notes']): ?><?php echo e($eachval['staff_notes']); ?> <?php else: ?> <?php echo e("NA"); ?> <?php endif; ?> </p>
													<p><b>Client Notes:</b> <?php if($eachval['client_notes']): ?><?php echo e($eachval['client_notes']); ?> <?php else: ?> <?php echo e("NA"); ?> <?php endif; ?> </p>
													
													
													
													<?php
														if(empty($eachval['staff_notes'])){
													?>

														<!--<button  class="btn btn-primary Mybtn_show">Add Note</button>
-->
														<form id="MyForm" action="<?php echo e(url('staff/submitNotesForm')); ?>" method="post">
														<?php echo csrf_field(); ?>
															<input type="hidden" name="id" value="<?php echo e($eachval['id']); ?>">
															<div class="form-group">
																<label for="staff_notes">Notes</label>
																<textarea required id="staff_notes" placeholder="Add your notes" class="form-control" name="staff_notes"><?php if(isset($timesheetDetail->staff_notes) && !empty($timesheetDetail->staff_notes)): ?><?php echo e($timesheetDetail->staff_notes); ?><?php else: ?><?php echo e(old('staff_notes')); ?><?php endif; ?></textarea>
																
															</div>
														<br>
														<input type="submit" class="btn btn-default" name="submit" value="Submit"/>
														</form>
													<?php
														}
													?>
												  </div>
												</div>
											
											  </div>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</div>
								</div>
								
								
							</div>
						</div>
					</div>
				
											
				</section>	
	
        </div>
      </div>
    </div>
	
<?php $__env->stopSection(); ?>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   
<?php $__env->startSection('footer-js'); ?>
	<style>
		span.fc-time {
    display: none;
}
.fc-event span {
    font-size: 12px;
    color: #FFF;
    font-weight: 100;
}
td.fc-highlight{
	pointer-event:none;
}

#MyForm{

width: 100%;
    border: 1px solid #ccc;
    padding: 14px;
    margin-top: 13px;
}	
	</style>
	<script>
		        $("#fc-selectable1").fullCalendar({

            header: { left: "prev,next today", center: "title", right: "month,agendaWeek,agendaDay" },

            //defaultDate: "2016-06-12",

            selectable: !0,

            selectHelper: !0,
/*
            select: function (t, e) {

                var a,

                    n = prompt("Event Title:");

                n && ((a = { title: n, start: t, end: e }), $("#fc-selectable").fullCalendar("renderEvent", a, !0)), $("#fc-selectable").fullCalendar("unselect");

            },*/

            editable: !0,

            eventLimit: !0,
            events: [
				<?php
					if(count($record) > 0){
						foreach($record as $each){
							$staffDetail = App\Helpers\CommonHelper::getStaffDetails($each->staff_id);
							
							$clientDetail = App\Helpers\CommonHelper::getClientDetails($each->client_id);
				?>
					{ 
					title: "<?php echo $each['time_in']; ?>-<?php echo $each['time_out']; ?> (<?php echo $clientDetail['name']; ?>)", 
					start: "<?php echo $each['date_in']; ?>T<?php echo $each['time_in']; ?>", 
					end: "<?php echo $each['date_in']; ?>T<?php echo $each['time_out']; ?>",
					 url: '<?php echo $each['id'];?>',
					 data:'aaaa'
					},
				<?php
						}
					}
				?>

            ],

        });
		
		 $(document).ready(function(){
        
         $(document).on('click','.fc-h-event ,.fc-event',function(){
            var id = $(this).attr('href');
           $('#myModal_'+id).modal('show');
            return false;
        });
        $(document).on('click','.fc-list-event-title a',function(e){
            e.preventDefault();
            var id = $(this).attr('href');
           $('#myModal_'+id).modal('show');
         
            return false;
        });
        
        $(document).on('click','.close',function(e){
            e.preventDefault();
           $('.modal').modal('hide');
         
            return false;
        });
    })

	</script>
<?php $__env->stopSection(); ?>

 

<?php echo $__env->make('layouts.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/staff/today-schedule.blade.php ENDPATH**/ ?>