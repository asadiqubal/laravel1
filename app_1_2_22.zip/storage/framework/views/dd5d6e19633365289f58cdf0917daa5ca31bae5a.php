<?php $__env->startSection('content'); ?>



<section class="flexbox-container">
    <div class="col-12 d-flex align-items-center justify-content-center">
        <div class="col-md-4 col-10 box-shadow-2 p-0">
            <div class="card border-grey border-lighten-3 m-0">
                <div class="card-header border-0">
                    <div class="card-title text-center">
                        <div class="p-1"><img src="<?php echo e(asset('/app-assets/images/logo.png')); ?>" alt="Scheduling System" class="img-fluid"></div>
                    </div>
                    <h6 class="card-subtitle line-on-side text-muted text-center font-small-3 pt-2"><span>Login with Diverse Senior Care</span></h6>
                </div>
                <div class="card-content">
                    <div class="card-body">
					
						 <?php if(session('success')): ?>
						<div class="alert alert-success fade in alert-dismissible show">                
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true" style="font-size:20px">×</span>
							</button>
							<?php echo e(session('success')); ?>

						</div>
						<?php endif; ?>
						<?php if(session('error')): ?>
						<div class="alert alert-danger fade in alert-dismissible show">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							  <span aria-hidden="true" style="font-size:20px">×</span>
							</button>    
							<?php echo e(session('error')); ?>

						</div>
						<?php endif; ?>
						<p class="mb-0 font-medium-1"  style="line-height:18px">Please set your new password.</p><br>
						<form id="submitpassword" class="form-horizontal form-simple" method="POST" action="<?php echo e(url('/staff/submitpassword')); ?>" novalidate>
							 <?php echo csrf_field(); ?>
						 <input type="hidden" name="user_id" value="<?php echo e($userid); ?>">
						
								
						
						
						<fieldset class="form-group position-relative has-icon-left">
							
							<input name="password" value="" type="password" class="form-control form-control-lg input-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="New Password" required>
							
							
							<div class="form-control-position">
								<i class="fa fa-key font-medium-4"></i>
							</div>
							
							 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left">
							
							<input name="cpassword" value="" type="password" class="form-control form-control-lg input-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cpassword" placeholder="Confirm Password" required>
							
							
							<div class="form-control-position">
								<i class="fa fa-key font-medium-4"></i>
							</div>
							
							 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</fieldset>
						
						
						
						<button type="submit" class="btn btn-info btn-lg btn-block welocme_btn">Save & Go to Login</button>
                        
						
                    </form>
					
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/client/setpassword.blade.php ENDPATH**/ ?>