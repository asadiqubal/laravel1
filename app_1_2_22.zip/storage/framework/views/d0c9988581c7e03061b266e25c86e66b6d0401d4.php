<?php $__env->startSection('content'); ?>


<section class="flexbox-container">
    <div class="col-12 d-flex align-items-center justify-content-center">
        <div class="col-md-4 col-10 box-shadow-2 p-0">
            <div class="card border-grey border-lighten-3 m-0">
                <div class="card-header border-0">
                    <div class="card-title text-center">
                        <div class="p-1"><img src="<?php echo e(asset('/app-assets/images/logo.png')); ?>" alt="Scheduling System" class="img-fluid"></div>
                    </div>
                    <h6 class="card-subtitle line-on-side text-muted text-center font-small-3 pt-2"><span>Login with Diverse Senior Care</span></h6>
                </div>
                <div class="card-content">
                    <div class="card-body">
					
						 <?php if(session('success')): ?>
						<div class="alert alert-success fade in alert-dismissible show">                
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true" style="font-size:20px">×</span>
							</button>
							<?php echo e(session('success')); ?>

						</div>
						<?php endif; ?>
						<?php if(session('error')): ?>
						<div class="alert alert-danger fade in alert-dismissible show">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							  <span aria-hidden="true" style="font-size:20px">×</span>
							</button>    
							<?php echo e(session('error')); ?>

						</div>
						<?php endif; ?>
						<p class="mb-0 font-medium-1"  style="line-height:18px">Please login with your email and temparray password sent on your regitered email.</p><br>
						<form class="form-horizontal form-simple" method="POST" action="<?php echo e(url('/staff/templogin')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
						
								
						<fieldset class="form-group position-relative has-icon-left mb-0">
							<input type="email" class="form-control form-control-lg input-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user-name" placeholder="Your Username" name="email" value="<?php echo e($username); ?>" required>
							<div class="form-control-position">
								<i class="ft-user font-medium-4"></i>
							</div>
							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</fieldset>
						<fieldset class="form-group position-relative has-icon-left">
							<input type="password" class="form-control form-control-lg input-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user-password" name="password" value="<?php echo e($password); ?>" placeholder="Temporary Password" required>
							<div class="form-control-position">
								<i class="fa fa-key font-medium-4"></i>
							</div>
							
							 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</fieldset>
						
						
						
						<button type="submit" class="btn btn-info btn-lg btn-block welocme_btn">Sign In</button>
                        
						
                    </form>
					
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-js'); ?>

    <!-- END PAGE LEVEL JS-->
	<script>
	   $(document).ready(function() {
		     $('.welocme_btn').click(function(){
			    
				$('.Welcome_box').hide();
				//$('.header_text').hide();
				$('.change_password').show();
			 
			 })
	  });
	</script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/staff/welcome.blade.php ENDPATH**/ ?>