


<?php $__env->startSection('content'); ?>


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Staff List</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Staff List
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					<div class="col-12 text-right mb-2"><a href="<?php echo e(url('admin/add-staff')); ?>" class="btn btn-danger rounded-0">Add New</a></div>
						<div class="col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
									
										 <?php if(session('success')): ?>
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												<?php echo e(session('success')); ?>

											</div>
											<?php endif; ?>
											<?php if(session('error')): ?>
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												<?php echo e(session('error')); ?>

											</div>
											<?php endif; ?>
										<table class="table table-striped table-bordered dom-jQuery-events">
											<thead>
											   <tr>
												<th>Name</th>
												<th>Date</th>
												<th>Joining Date</th>
												<th>Registery No.</th>
												<th>Licence No.</th>
												<th>Expiry Date</th>
												<th>Actions</th>   
											   </tr>
											</thead>
											<tbody>
												<?php if(count($staff_list) > 0): ?>
													<?php $__currentLoopData = $staff_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
													   
														<td><img width="40" height="40" src="<?php echo e(asset('staff')); ?>/<?php echo e($eachitem['photo']); ?>" class="rounded-circle mr-1" alt=""> <?php echo e($eachitem['name']); ?></td>
														 <td>10 Oct 2021</td>
														 <td><?php echo e($eachitem['joining_date']); ?></td>
														  <td><?php echo e($eachitem['registery_no']); ?></td>
														  <td><?php echo e($eachitem['licence_no']); ?></td>
														
															<td><?php echo e($eachitem['expiry_date']); ?></td>
														<td><a href="<?php echo e(url('admin/edit-staff')); ?>/<?php echo e($eachitem['id']); ?>">Edit</a> | <a onclick="deleteFunc('Staff',<?php echo e($eachitem['id']); ?>)" href="#">Delete</a></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
												
											</tfoot>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/admin/staff-list.blade.php ENDPATH**/ ?>