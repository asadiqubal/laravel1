<?php $__env->startSection('content'); ?>

<style>
    .remove-input-field{
        display:none;
    }
    #dynamicAddRemove .remove-input-field{
        display:block;
    }
    .appended_div{
        padding:13px;
        border-bottom: 1px solid #000;
    }
    #main_form .appended_div {
          background: #ddd;
      }
      .appended_div:nth-child(2n) {
          background: #ccc;
      }
      
      .error{
          color: #e14a4a;
      }

</style>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Add Schedule</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Add Schedule
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					
						<div class="col-md-12 col-sm-12 col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
									
										 <?php if(session('success')): ?>
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												<?php echo e(session('success')); ?>

											</div>
											<?php endif; ?>
											<?php if(session('error')): ?>
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												<?php echo e(session('error')); ?>

											</div>
											<?php endif; ?>
											<form id="addStaffForm" class="form-horizontal form-simple" method="POST" action="<?php echo e(url('admin/submitaddSchedule')); ?>" novalidate  enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
											<?php if(isset($id) && !empty($id)): ?>
												<input type="hidden" name="id" value="<?php echo e($id); ?>">
											<?php endif; ?>
											<div class="form-body">
												<div class="" id="main_form" >
												    <div class="row appended_div" style="width: 100%;">
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput3">Client</label>
															<select name="client_id[]" class="client_id form-control required" required>
															<option value="">Select Client</option>
															<?php if(count($ClientList) > 0): ?>
																<?php $__currentLoopData = $ClientList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachstaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<option <?php if(isset($timesheetDetail->client_id) && $timesheetDetail->client_id == $eachstaff->id): ?> selected <?php endif; ?> value="<?php echo e($eachstaff->id); ?>"><?php echo e($eachstaff->name); ?></option>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
															</select>
															
															
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="staff_id">Employee</label>
															<select name="staff_id[]"  class="staff_id form-control required" required>
															<option value="">Select Staff</option>
															<?php if(count($StaffList) > 0): ?>
																<?php $__currentLoopData = $StaffList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachstaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<option <?php if(isset($timesheetDetail->staff_id) && $timesheetDetail->staff_id == $eachstaff->id): ?> selected <?php endif; ?> value="<?php echo e($eachstaff->id); ?>"><?php echo e($eachstaff->name); ?> - <?php echo e($eachstaff->employee_code); ?></option>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
															</select>
															
															
														</div>
													</div>
													
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="date_in">Date</label>
															<?php
															    if(isset($_GET['booking_date']) && !empty($_GET['booking_date'])){  $date = $_GET['booking_date'];}else{ $date = old('date_in'); }
														    ?> 
															<input type="date" id="date_in" class="date_in form-control required" name="date_in[]" value="<?php if(isset($timesheetDetail->date_in) && !empty($timesheetDetail->date_in)): ?><?php echo e($timesheetDetail->date_in); ?><?php else: ?><?php echo e($date); ?><?php endif; ?>" required>
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="time_in">Start Time</label>
															<input type="time" id="time_in" class="time_in form-control required" name="time_in[]" value="<?php if(isset($timesheetDetail->time_in) && !empty($timesheetDetail->time_in)): ?><?php echo e($timesheetDetail->time_in); ?><?php else: ?><?php echo e(old('time_in')); ?><?php endif; ?>" required>
														</div>
														
													</div>
													<div class="col-md-6 col-sm-12 col-12">
													
													
														<div class="form-group">
															<label for="time_out">End Time</label>
															<input type="time" id="time_out" class="time_out form-control required" name="time_out[]" value="<?php if(isset($timesheetDetail->time_out) && !empty($timesheetDetail->time_out)): ?><?php echo e($timesheetDetail->time_out); ?><?php else: ?><?php echo e(old('time_out')); ?><?php endif; ?>" required>
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
													
													
														<div class="form-group">
															<label for="admin_notes">Notes</label>
															<textarea id="admin_notes" class="form-control" name="admin_notes[]"><?php if(isset($timesheetDetail->admin_notes) && !empty($timesheetDetail->admin_notes)): ?><?php echo e($timesheetDetail->admin_notes); ?><?php else: ?><?php echo e(old('admin_notes')); ?><?php endif; ?></textarea>
															
														</div>
													</div>
													
												<button type="button" class="btn btn-outline-danger remove-input-field col-md-1 col-sm-1 col-1" style="float: right;left: 90%;margin-bottom: 27px;">Remove</button>
													<hr>
													
												</div>
												</div>
												<div class="row1" id="dynamicAddRemove">
												    
    												 
    												 
												</div>
												
												
												
											   												
											</div>

											<div class="form-actions text-right">
											    <button type="button" name="add" id="dynamic-ar" class="btn btn-outline-primary">Add More Schedule</button>
											    
												<button name="submit" type="submit" class="btn btn-info rounded-0">
													Submit
												</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->


   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-js'); ?>
    <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>

<script type="text/javascript">
    var i = 0;
    $("#dynamic-ar").click(function () {
        ++i;
        var main_form = $("#main_form").html();
       // var main_form = main_form+"<button type='button' class='btn btn-outline-danger remove-input-field'>Remove</button>";
        $("#dynamicAddRemove").append(main_form);
        
        var client_id = $('.client_id').val();
        $('.client_id').val(client_id);
        
        var staff_id = $('.staff_id').val();
        $('.staff_id').val(staff_id);
        
        var date_in = $('.date_in').val();
        $('.date_in').val(date_in);
        
        
        $('.required').each(function() {
			$(this).rules("add", 
				{
					required: true,
					messages: {
						required: "Please enter value",
					}
				});
		});
    });
    $(document).on('click', '.remove-input-field', function (e) {

     var html=   $(this).parent('#dynamicAddRemove .appended_div').remove();
    
    
    });
    
    
    
	
	$("#addStaffForm").validate({
		required: true,
		messages: {
			required: "Please enter value.",
		}
	});
	
	
	
		
	
	
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c5wjic7ffkcf/public_html/diverseseniorcare.com/scheduling/resources/views/admin/add-schedule.blade.php ENDPATH**/ ?>