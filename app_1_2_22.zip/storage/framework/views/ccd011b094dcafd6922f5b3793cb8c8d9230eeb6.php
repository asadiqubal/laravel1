<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>