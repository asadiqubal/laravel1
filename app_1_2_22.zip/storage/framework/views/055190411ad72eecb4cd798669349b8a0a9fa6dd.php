


<?php $__env->startSection('content'); ?>



    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Add Marketing</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Add Marketing
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					
						<div class="col-md-12 col-sm-12 col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
									   <form class="form">
											<div class="form-body">
												<div class="row">
													<div class="col-md-6 col-sm-12 col-12">
															<div class="form-group">
																<label for="projectinput3">Referral Source</label>
																<input type="text" id="projectinput3" class="form-control" name="ReferralSource">
															</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput3">Name</label>
															<input type="text" id="projectinput3" class="form-control" name="companyname">
														</div>
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput5">Phone</label>
															<input type="text" id="projectinput5" class="form-control" name="Phone">
														</div>
														
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput4">Address</label>
															<textarea id="projectinput4" class="form-control"> </textarea>
															
														</div>
														
													</div>
													
													<div class="col-md-6 col-sm-12 col-12">
														<div class="form-group">
															<label for="projectinput3">Business Name</label>
															<input type="email" id="projectinput3" class="form-control" name="address">
														</div>
													</div>
													<div class="col-md-6 col-sm-12 col-12">
													<div class="form-group">
															<label for="projectinput3">Last Contact Date</label>
															<input type="date" id="projectinput3" class="form-control" name="age">
														</div>
													</div>
												</div>
																								
											</div>

											<div class="form-actions text-right">
												<button type="submit" class="btn btn-info rounded-0">
													Submit
												</button>
											</div>
										</form>
									
									
										
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/add-marketing.blade.php ENDPATH**/ ?>