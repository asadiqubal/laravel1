<?php $__env->startSection('content'); ?>

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Timesheet</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Timesheet
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					
				<div class="row">
					<div class="col-12">
						<div class="card">
						   
							<div class="card-content collapse show">
								<div class="card-body card-dashboard">
								
										 <?php if(session('success')): ?>
											<div class="alert alert-success fade in alert-dismissible show">                
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true" style="font-size:20px">×</span>
												</button>
												<?php echo e(session('success')); ?>

											</div>
											<?php endif; ?>
											<?php if(session('error')): ?>
											<div class="alert alert-danger fade in alert-dismissible show">
												<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												  <span aria-hidden="true" style="font-size:20px">×</span>
												</button>    
												<?php echo e(session('error')); ?>

											</div>
											<?php endif; ?>
								<div class="row justify-content-end">
									<div class="col-md-2 col-sm-12 col-12 pt-1 text-right"><b>Select Date</b></div>	
									<?php
										if(isset($_GET['date']) && !empty($_GET['date'])){
											$currentData = $_GET['date'];
										}else{
												$currentData = date('Y-m-d');
										}
										
									?>
									<div class="col-md-3 col-sm-12 col-12 mb-2 text-right"><input type="date" class="date_in_selectform form-control" value="<?php echo e($currentData); ?>"></div>

								</div>
								
								
									<table class="table table-striped table-bordered dom-jQuery-events">
										<thead>
											<tr>
											   <th>Date</th>
											   <th>Employee Name</th>
												<th>Time In</th>
												<th>Time Out</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php if(count($timesheet_list) > 0): ?>
												<?php $__currentLoopData = $timesheet_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($each->date_in); ?> </td>
														<td><?php echo e($each->name); ?> </td>
														<td><?php echo e($each->time_in); ?></td>
														<td><?php echo e($each->time_out); ?></td>
														<td><a href="<?php echo e(url('admin/edit-timesheet')); ?>/<?php echo e($each->id); ?>">Edit</a> | <a onclick="deleteFunc('Timesheet',<?php echo e($each->id); ?>)" href="#">Delete</a></td>
													</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
											
											
											
										</tbody>
									</table>
							   
										
										
										

							   </div>
							</div>
						</div>
					</div>
				</div>	
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-js'); ?>
<script>
	$('.date_in_selectform').on('change', function(){
	   window.location = "timesheet/?date="+$(this).val();
	});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c5wjic7ffkcf/public_html/diverseseniorcare.com/scheduling/resources/views/admin/timesheet.blade.php ENDPATH**/ ?>