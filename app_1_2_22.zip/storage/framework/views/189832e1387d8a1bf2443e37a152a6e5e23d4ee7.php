<?php $__env->startSection('content'); ?>


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Past Visits</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item"><a href="#">Staff</a>
					</li>
					<li class="breadcrumb-item active">Past Visits
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					<div class="row">
					<!--<div class="col-12 text-right mb-2"><a href="add-staff.html" class="btn btn-danger rounded-0">Add New</a></div>-->
						<div class="col-12">
							<div class="card">
							   
								<div class="card-content collapse show">
									<div class="card-body card-dashboard">
										<table class="table table-striped table-bordered dom-jQuery-events">
											<thead>
											   <tr>
												<th>Time</th>
												<th>Client Name</th>
												<th>Address</th>
												<th>Status</th>
												<th>Actions</th>   
											   </tr>
											</thead>
											<tbody>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Completed</td>
													<td><a href="#">View Detail</a></td>
												</tr>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Cancelled By Client</td>
													<td><a href="#">View Detail</a></td>
												</tr>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Completed</td>
													<td><a href="#">View Detail</a></td>
												</tr>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Cancelled By Client</td>
													<td><a href="#">View Detail</a></td>
												</tr>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Completed</td>
													<td><a href="#">View Detail</a></td>
												</tr>
												<tr>
													<td>11:00 AM</td>
													<td>Adam Smith</td>
													<td>123 street Park Lane, New York 110011</td>
													<td>Cancelled By Client</td>
													<td><a href="#">View Detail</a></td>
												</tr>
											</tfoot>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
										
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/staff/past-visit.blade.php ENDPATH**/ ?>