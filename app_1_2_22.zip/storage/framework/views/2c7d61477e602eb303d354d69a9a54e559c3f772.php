<footer class="footer footer-static footer-light navbar-border">
  <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright  &copy; 2021 
  Diverse Senior Care, All rights reserved. </span>
  </p>
</footer>






<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!--<script src="app-assets/vendors/js/charts/raphael-min.js"></script>
<script src="app-assets/vendors/js/charts/morris.min.js"></script>
<script src="app-assets/vendors/js/charts/chart.min.js"></script>
<script src="app-assets/vendors/js/charts/jvector/jquery-jvectormap-2.0.3.min.js"></script>
<script src="app-assets/vendors/js/charts/jvector/jquery-jvectormap-world-mill.js"></script>
<script src="app-assets/vendors/js/extensions/moment.min.js"></script>
<script src="app-assets/vendors/js/extensions/underscore-min.js"></script>
<script src="app-assets/vendors/js/extensions/clndr.min.js"></script>
<script src="app-assets/vendors/js/charts/echarts/echarts.js"></script>
<script src="app-assets/vendors/js/extensions/unslider-min.js"></script>-->
<!-- END PAGE VENDOR JS-->
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/core/libraries/jquery_ui/jquery-ui.min.js')); ?>"></script>
<!-- BEGIN ROBUST JS-->
<script src="<?php echo e(asset('app-assets/js/core/app-menu.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/core/app.min.js')); ?>"></script>
<!-- BEGIN PAGE LEVEL JS-->
<script src="<?php echo e(asset('app-assets/js/scripts/extensions/fullcalendar.min.js')); ?>"></script><?php /**PATH /home/customer/www/asadi1.sg-host.com/public_html/diversecare/resources/views/partial/footer.blade.php ENDPATH**/ ?>