<?php $__env->startSection('content'); ?>


    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
			  <div class="content-header-left col-md-6 col-12 mb-1">
				<h3 class="content-header-title">Timesheet</h3>
			  </div>
			  <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
				<div class="breadcrumb-wrapper col-12">
				  <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html">Home</a>
					</li>
					<li class="breadcrumb-item active">Timesheet
					</li>
				  </ol>
				</div>
			  </div>
        </div>
        <div class="content-body"><!-- Sales stats -->
		
				<section id="dom">
					
				<div class="row">
					<div class="col-12">
						<div class="card">
						   
							<div class="card-content collapse show">
								<div class="card-body card-dashboard">
								<div class="row justify-content-end">
									<div class="col-md-3 col-sm-12 col-12 text-right"><select class="form-control"> 
									<option selected >month</option>
									<option value="Jan">Jan</option>
									<option value="">Feb</option>
									<option value="">Mar</option>
									<option value="Apr">Apr</option>
									</select></div>		
									<div class="col-md-3 col-sm-12 col-12 mb-2 text-right"><select class="form-control"> 
									<option selected >Year</option>
									<option value="Jan">2021</option>
									<option value="">2020</option>
									<option value="">2019</option>
									<option value="Apr">2018</option>
									</select>
									</div>

								</div>
								
								
									<table class="table table-striped table-bordered dom-jQuery-events">
										<thead>
											<tr>
											   <th>Date</th>
												<th>Time In</th>
												<th>Time Out</th>
												<th>Attendence</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>11 Oct 2021 </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td>Present</td>
											</tr>
											<tr>
												<td>11 Oct 2021  </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td>Present</td>
											</tr>
											<tr>
												<td>13 Oct 2021  </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td>Absent</td>
											</tr>
											<tr>
												<td>11 Oct 2021  </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td>Present</td>
											</tr>
										   <tr>
												<td>11 Oct 2021  </td>
												<td>10:00 AM</td>
												<td>10:30 AM</td>
												<td>Present</td>
											</tr>
										
											
										</tfoot>
									</table>
							   
										
										
										

							   </div>
							</div>
						</div>
					</div>
				</div>	
					
</section>
<!-- DOM - jQuery events table -->
	


        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\diversecare\diversecare\resources\views/staff/timesheet.blade.php ENDPATH**/ ?>