<p><?php echo $message2; ?>.</p>
<?php /**PATH /home/c5wjic7ffkcf/public_html/diverseseniorcare.com/scheduling/resources/views/email/new-user-create.blade.php ENDPATH**/ ?>